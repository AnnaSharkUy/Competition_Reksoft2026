import { test } from '@playwright/test';

/*
Frontier Id: 6671
Area: Библиотека/Загрузка
Priority: High Status: Actual
Automation: gap
Reason: Шаги завязаны на ручные данные стенда. Файл-заготовка: дописать селекторы и только свои данные.
Preconditions: 
Expected: 
Step 0: Авторизоваться
Step 1: Загрузить файл
Step 2: Проверить карточку ассета
Step 3: Открыть превью и проверить
Step 4: Открыть ассет и проверить страницу ассета
Импорт в Frontier: testcases-import/6671.json
*/

test('6671 Загрузка документов', async () => {
  test.fixme(true, 'Шаги завязаны на ручные данные стенда. Файл-заготовка: дописать селекторы и только свои данные.');
});
